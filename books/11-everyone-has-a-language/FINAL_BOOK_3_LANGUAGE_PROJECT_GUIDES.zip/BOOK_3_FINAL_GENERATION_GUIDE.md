# BOOK 3 — FINAL GENERATION GUIDE

# TITLE RESEARCH AND DIRECTION

## Recommended title
# EVERYONE HAS A LANGUAGE
### Subtitle: The Many Ways We Speak, Create, and Change the World

Several intuitive alternatives were checked against current book records and are less distinctive:
- **The Language of Everything** already appears as a book title.
- **Your Life Is Your Message** is an established title associated with Eknath Easwaran.
- **What Are You Saying?** is used by multiple communication/public-speaking books.
- **Speak Without Words** is used by books about body language.
- **Everything Speaks** is already used as a title and in closely related phrasing.

Therefore, do not lock the project to those exact titles.

Other candidates to keep for later cover/title testing:
- WHAT LANGUAGE DO YOU HAVE?
- THE LANGUAGE YOU CHOOSE
- EVERY HUMAN BEING HAS A LANGUAGE
- HOW WILL YOU SPEAK?
- THE WORLD IS LISTENING
- MORE THAN WORDS
- YOUR OTHER LANGUAGE
- THE THINGS WE USE TO SPEAK

Before publication, perform a proper trademark/title-market check.

# CORE PROMISE

The book invites readers to rethink language.

Language is not only vocabulary, grammar, and speech.

People communicate through:
- words
- music
- code
- software
- drawings
- cartoons
- farming
- teaching
- architecture
- fashion
- film
- business
- craftsmanship
- parenting
- choices
- behavior
- silence
- service
- creation

The central question:

> **What language do you have, and what message are you sending with it?**

# IMPORTANT DISTINCTION

**Medium ≠ message ≠ morality.**

A tool is a medium. A person chooses how to use it. The resulting creation or action communicates something. But communication itself does not make an action good.

A song can comfort or glorify hatred. Technology can solve problems or facilitate harm. A drawing can expose injustice or spread a lie.

The book must distinguish:
**ability to communicate → content → interpretation → consequences → responsibility.**

# PROLOGUE — BEFORE WE LEARN TO SPEAK

Open with a child who cannot yet speak:
a cry, a gesture, a hand reaching, a face turning toward a parent.

Before vocabulary, there is already communication.

Widen the idea: humans spend their lives learning increasingly sophisticated ways to place meaning into the world.

End with:

> **What language will you use when the world is waiting to hear from you?**

# PART I — LANGUAGE IS BIGGER THAN WORDS

## 1. THE FIRST LANGUAGE
Gesture, expression, sound, movement, attention, imitation. Use scenes rather than a technical lecture.

## 2. THE LANGUAGE OF WORDS
Speech, writing, books, letters, conversations. Words remain powerful, but they are one language among many.

## 3. WHEN MUSIC SPEAKS
Explore melody, rhythm, instruments, lyrics, silence, and cultural memory.

Core idea:
> Sometimes the thing we cannot explain is the thing we can sing.

## 4. WHEN PICTURES SPEAK
Painters, photographers, illustrators, and cartoonists. A visual image can compress a complex idea into one moment.

If using real cartoonists such as Dr. Jim Spire Ssentongo, verify specific examples and attribute them accurately.

## 5. THE LANGUAGE OF CODE
Use the author's technology perspective authentically, but do not turn the book into a programming manual.

Explore code as a formal system that lets humans construct systems and experiences.

Key line to develop:
> **I write instructions for a machine, but people live inside what I build.**

# PART II — THE TOOLS IN OUR HANDS

## 6. THE FARMER'S LANGUAGE
A field, seed, hoe, tractor, harvest, season, uncertainty, patience, and labor can become forms through which a farmer contributes and communicates values.

Central metaphor:
> A field can become a sentence written across the earth.

Do not romanticize farming.

## 7. THE TEACHER'S LANGUAGE
Explanation, questions, examples, patience, correction, encouragement, and classroom example.

## 8. THE MAKER'S LANGUAGE
Craftspeople, mechanics, builders, engineers, technicians. A repaired engine, chair, bridge, or tool can communicate care and competence.

## 9. THE FASHION DESIGNER'S LANGUAGE
Clothing can communicate identity, culture, creativity, belonging, confidence, celebration, protest, and status.

Ask:
> Are you creating merely to attract attention, or do you have something meaningful to express?

Do not judge people's clothing choices.

## 10. THE CAMERA'S LANGUAGE
Film and photography: perspective, editing, memory, documentary, storytelling, and responsibility.

# PART III — EVERYTHING WE DO CAN SPEAK

## 11. THE LANGUAGE OF WORK
Repeatedly giving time to something communicates priorities, while recognizing that survival work and chosen vocation are not the same thing.

## 12. THE LANGUAGE OF SILENCE
Silence can communicate peace, grief, fear, respect, anger, avoidance, or uncertainty. Context matters.

## 13. THE LANGUAGE OF CHOICE
Choices become patterns. Patterns become visible. Visible patterns communicate.

## 14. THE LANGUAGE OF CHARACTER
Repeated behavior can reveal something that claims may hide. Avoid simplistic “actions speak louder than words” clichés.

## 15. THE LANGUAGE OF LOVE
Care can be communicated through showing up, listening, feeding, helping, teaching, protecting, apologizing, and giving time.

# PART IV — WHEN THE MESSAGE BECOMES DESTRUCTIVE

## 16. NOT EVERY MESSAGE DESERVES TO BE FOLLOWED
A person may communicate through action without making the action acceptable.

Discuss theft, assault, sexual violence, murder, terrorism, and intimidation only at a high level and without operational detail.

Point:
> **A destructive act can send a message while violating another person's rights and causing serious harm.**

## 17. THE DAMAGE A MESSAGE CAN CAUSE
Messages can educate, unite, and heal, but can also deceive, humiliate, manipulate, incite, traumatize, or destroy trust.

## 18. FREEDOM AND RESPONSIBILITY
Expression matters. So do the dignity and safety of other people.

Core point:
> **Having the ability to speak does not remove responsibility for what you choose to communicate or how you communicate it.**

# PART V — FIND YOUR LANGUAGE

## 19. YOU ALREADY HAVE SOMETHING
Ask:
- What can you make?
- What can you teach?
- What can you repair?
- What can you write?
- What can you build?
- What can you grow?
- What can you perform?
- What can you design?
- What problem can you solve?

## 20. USE WHAT IS IN YOUR HANDS
Do not wait for perfect equipment. Use what is available: a phone, pen, computer, field, classroom, camera, sewing machine, instrument, workshop, kitchen, voice, or hands.

> **Your medium does not have to look like someone else's.**

## 21. MASTER YOUR LANGUAGE
Having a medium is not enough. Musicians practice, programmers debug, farmers learn, teachers study, writers rewrite, designers learn, mechanics learn machines.

## 22. WHAT ARE YOU SAYING?
Bring the argument together. Examine work, relationships, creations, online presence, choices, habits, treatment of others, ambitions, failures, and contribution.

Ask:
> **If your life were translated into a language the world could read, what would it say?**

# EPILOGUE — SPEAK

Return to the child from the prologue, now grown.

They may speak through code, music, farming, teaching, art, business, parenting, or something not yet named.

Closing direction:

> You were never required to speak the same language as everyone else.
>
> You were given something.
>
> A mind.
> Hands.
> Time.
> Imagination.
> Experience.
>
> Find the language that is yours.
>
> Learn it.
> Use it.
> Make it worthy of the people who will receive it.
>
> Because the world is full of people trying to say something.
>
> **Now ask yourself what you are saying.**

# CHARACTER AND EXAMPLE ENGINE

Use fictional/composite characters and carefully researched real-world examples:
- programmer building an app from a small room
- farmer planting before knowing whether the rains will come
- teacher staying after class with a struggling student
- musician unable to explain grief but able to play it
- cartoonist turning a complex social issue into one image
- fashion designer carrying cultural meaning through clothing
- parent whose children learn more from behavior than lectures

Characters should have flaws, uncertainty, humor, setbacks, and consequences.

# GLOBAL WRITING RULES

DO:
- show before explaining
- use concrete scenes
- use dialogue where useful
- use sensory details
- include warmth and humor
- allow uncertainty
- respect professions
- show both constructive and destructive uses of communication
- distinguish evidence from interpretation
- research real examples

AVOID:
- motivational-poster clichés
- repetitive “change the world” speeches
- romanticizing poverty or struggle
- framing criminals as noble communicators
- reducing communication to body language
- preaching
- invented facts or quotations
- excessive metaphors
- repetitive thesis statements
- living-author imitation

# EMOTIONAL ARC

**Curiosity → Recognition → Wonder → Identification → Responsibility → Self-examination → Possibility**

The reader should recognize themselves in at least one chapter.
