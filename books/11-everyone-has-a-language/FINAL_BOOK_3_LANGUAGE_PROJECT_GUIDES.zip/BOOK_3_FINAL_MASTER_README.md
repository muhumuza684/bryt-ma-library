# BOOK 3 PROJECT — FINAL MASTER README

## Working title
# EVERYONE HAS A LANGUAGE
### The Many Ways We Speak, Create, and Change the World

## Core concept
Human communication is broader than spoken and written words. People place meaning into the world through whatever medium, craft, action, creation, or behavior they use.

A musician speaks through music. A writer through words. A programmer through code and software. A farmer through cultivation. A teacher through a classroom. A cartoonist through images. A fashion designer through clothing. A filmmaker through film. A parent through everyday example.

The central questions are:

> **WHAT LANGUAGE DO YOU HAVE?**

> **WHAT ARE YOU SAYING WITH IT?**

> **WHAT HAPPENS TO OTHER PEOPLE BECAUSE OF WHAT YOU SAY?**

## Refined thesis
Everyone has some means of expression, but having a medium does not make every message good. Expression creates responsibility.

The book therefore moves through:
1. Everyone has a language or medium of expression.
2. Different people speak through different mediums.
3. Actions and creations communicate whether we intend them to or not.
4. Because messages affect other people, we should choose and use our language responsibly.

## Research-informed craft
Research on narrative transportation supports using immersive stories and emotionally meaningful scenes rather than writing the book as a lecture. Experimental and review literature has linked narrative engagement with empathy, attitudes, and behavioral intentions, while also emphasizing that effects depend on how readers engage with stories. These findings inform craft; they are not guarantees that this particular book will change readers.

## Publishing principles
KDP requires the title/subtitle and cover metadata to accurately match the book and recommends relevant rather than misleading keywords and categories. Final metadata should be selected after the manuscript is complete.

## Tone
Philosophical, accessible, emotional without manipulation, hopeful without cliché, culturally inclusive, concrete, and thought-provoking.

## Distinctive proposition
The book is NOT simply about body language or communication skills.

Its broader subject is:

> **The many languages through which human beings place meaning into the world.**

## Recurring structure
A recurring progression should develop naturally:

**TOOL → LANGUAGE → MESSAGE → CONSEQUENCE → RESPONSIBILITY**

Recurring objects may include a blank page, cursor, seed, musical note, chalk mark, camera lens, needle/thread, tool in a hand, and a message being received.

The structure should reward rereading without becoming a puzzle gimmick.

## Final reader effect
The reader should finish thinking:

> “I have a language too.”

Then:

> “What have I been saying with it?”

And finally:

> “I should use what I have to create something worth hearing.”
