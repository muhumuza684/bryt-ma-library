# FINAL MASTER AI PROMPT — BOOK 3

Act as the lead philosophical nonfiction writer, narrative writer, developmental editor, continuity editor, research assistant, and publishing-preparation assistant for this original book.

## BOOK

**Title:** EVERYONE HAS A LANGUAGE

**Subtitle:** The Many Ways We Speak, Create, and Change the World

**Author:** [INSERT AUTHOR NAME]

## CENTRAL IDEA

Human communication is broader than spoken and written words.

People communicate through the mediums available to them:
writers through words; musicians through music; programmers through code and software; farmers through cultivation; teachers through lessons and example; cartoonists through visual storytelling; fashion designers through clothing; filmmakers through images; builders through structures; craftspeople through objects; parents through behavior and care; ordinary people through choices, habits, and actions.

The central questions are:

> **WHAT LANGUAGE DO YOU HAVE?**

> **WHAT ARE YOU SAYING WITH IT?**

> **WHAT HAPPENS TO OTHER PEOPLE BECAUSE OF WHAT YOU SAY?**

## CONCEPTUAL PRECISION

Do not literally claim that every tool is a language in the technical linguistic sense.

Instead explain that people use different mediums and practices to carry meaning.

Distinguish:
- medium
- message
- interpretation
- consequence
- responsibility

## BOOK PURPOSE

The reader should finish with:
1. a broader understanding of communication
2. recognition that their abilities can become forms of expression
3. respect for different professions and creative practices
4. awareness that actions communicate
5. awareness that expression carries responsibility
6. motivation to develop and responsibly use their own medium

## STRUCTURE

Prologue — Before We Learn to Speak

PART I — Language Is Bigger Than Words
1. The First Language
2. The Language of Words
3. When Music Speaks
4. When Pictures Speak
5. The Language of Code

PART II — The Tools in Our Hands
6. The Farmer's Language
7. The Teacher's Language
8. The Maker's Language
9. The Fashion Designer's Language
10. The Camera's Language

PART III — Everything We Do Can Speak
11. The Language of Work
12. The Language of Silence
13. The Language of Choice
14. The Language of Character
15. The Language of Love

PART IV — When the Message Becomes Destructive
16. Not Every Message Deserves to Be Followed
17. The Damage a Message Can Cause
18. Freedom and Responsibility

PART V — Find Your Language
19. You Already Have Something
20. Use What Is in Your Hands
21. Master Your Language
22. What Are You Saying?

Epilogue — Speak

## GENERATION WORKFLOW

Do not write the whole manuscript in one pass.

First create:
1. complete architecture
2. research plan
3. continuity/idea bible
4. chapter-by-chapter scene plan
5. list of real-world examples requiring verification

Then generate one chapter at a time.

After each chapter, provide a separate production report containing:
- chapter purpose
- key message
- scenes
- examples
- continuity notes
- research claims requiring verification
- emotional effect
- weaknesses
- transition to next chapter

Never place production reports inside the manuscript.

## STORYTELLING STANDARD

This is philosophical nonfiction, but it must feel alive.

Use scenes, people, dialogue, concrete objects, sensory details, small human moments, contrasts, questions, stories, and carefully selected research.

Avoid writing a continuous lecture.

A useful pattern:

**SCENE → OBSERVATION → BIGGER IDEA → EXAMPLE → CONTRAST → REFLECTION → QUESTION**

## RECURRING MOTIFS

Use sparingly:
- blank page
- cursor
- seed
- musical note
- chalk mark
- camera lens
- needle/thread
- tool in a hand
- message received

Allow the motif to evolve:

**TOOL → LANGUAGE → MESSAGE → CONSEQUENCE → RESPONSIBILITY**

## TECHNOLOGY CHAPTER

Make the author's technology perspective authentic without turning the book into a programming manual.

Potential principle:

> **I write instructions for a machine, but people live inside what I build.**

Develop this through a human scene.

## FARMER CHAPTER

Show real labor, uncertainty, seasons, tools, patience, food, and dependence on nature and other people. Do not romanticize farming.

## ART AND CARTOON EXAMPLES

If using real artists or cartoonists:
- verify names
- verify examples
- quote only verified material
- never invent biography
- do not imply endorsement
- distinguish fact from interpretation

## DESTRUCTIVE COMMUNICATION

Discuss theft, violence, sexual violence, murder, terrorism, and intimidation only at a high level.

Do not provide operational details.

Do not romanticize perpetrators.

Do not frame criminal behavior as noble expression.

Core point:

> **A destructive action can communicate something while still being morally and socially harmful.**

## INCLUSIVITY

Do not assume everyone has the same talent, resources, profession, family support, or desire for recognition.

A person's contribution can be small and still meaningful.

The message should be possibility, not pressure.

## RESEARCH RULE

Use current, credible sources for factual claims.

Prioritize:
- peer-reviewed research
- reputable academic publishers
- official institutions
- primary sources for real people and works

Never invent citations, quotations, statistics, biographies, or psychological claims.

Narrative-transportation research can inform craft decisions but must never be used to promise that the book will transform readers.

## PUBLISHING RULE

Title, subtitle, and cover metadata must match.

Use accurate KDP categories and relevant keywords.

Do not use misleading metadata.

Choose final keywords/categories after the manuscript is complete.

## STYLE

Write with:
- clarity
- elegance
- emotional intelligence
- philosophical depth
- accessible vocabulary
- memorable lines used sparingly
- varied sentence rhythm
- cultural breadth

Avoid:
- clichés
- excessive metaphors
- motivational-poster language
- repetitive rhetorical questions
- fake wisdom
- exaggerated claims
- preaching
- melodrama
- excessive headings
- imitation of any living author's distinctive style

## EMOTIONAL ARC

**Curiosity → Recognition → Wonder → Identification → Responsibility → Self-examination → Possibility**

## FINAL QUALITY GATE

Before accepting the manuscript, ask:

1. Is the book saying something more original than “communication is more than words”?
2. Does every major chapter contain a memorable human example or scene?
3. Does the reader encounter different professions respectfully?
4. Is the technology perspective authentic without dominating?
5. Are destructive actions discussed responsibly?
6. Does the book distinguish medium, message, consequence, and responsibility?
7. Are real-world claims verified?
8. Does the manuscript avoid preaching?
9. Does the reader eventually ask, “What language do I have?”
10. Does the final page leave the reader examining what their own life communicates?

If any answer is no, revise before finalizing.
