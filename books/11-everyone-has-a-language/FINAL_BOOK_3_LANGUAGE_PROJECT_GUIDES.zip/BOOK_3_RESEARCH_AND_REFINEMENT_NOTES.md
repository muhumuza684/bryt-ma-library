# BOOK 3 — RESEARCH & REFINEMENT NOTES

## 1. Narrative immersion

Research on narrative transportation supports the decision to make this a story-rich philosophical book rather than a continuous lecture.

A 2013 PLOS ONE experimental study examined fiction reading and empathy and reported changes in empathy under conditions involving emotional transportation into the story. A 2024 systematic review examined 95 peer-reviewed articles on narrative transportation and described links between story immersion, emotional/cognitive engagement, attitudes, and behavioral intentions. A 2024 academic chapter by Green and Appel synthesizes research on transportation as immersion in a narrative world and discusses effects on attitudes, beliefs, behavior, and social cognition.

These findings inform writing craft; they do **not** guarantee that this book will change readers or succeed commercially.

## 2. Title research

Current book records make several obvious titles less distinctive:

- **The Language of Everything** — existing books were found, including a 2026 publication and a 2020 novel.
- **Your Life Is Your Message** — an established title associated with Eknath Easwaran.
- **What Are You Saying?** — multiple existing communication/public-speaking books use this title.
- **Speak Without Words** — existing books use this title for body-language themes.
- **Everything Speaks** — already appears as a title and closely related phrase.

### Recommended direction
**EVERYONE HAS A LANGUAGE**

Recommended subtitle:
**The Many Ways We Speak, Create, and Change the World**

Alternatives to retain for later testing:
- WHAT LANGUAGE DO YOU HAVE?
- THE LANGUAGE YOU CHOOSE
- EVERY HUMAN BEING HAS A LANGUAGE
- HOW WILL YOU SPEAK?
- THE WORLD IS LISTENING
- MORE THAN WORDS
- YOUR OTHER LANGUAGE
- THE THINGS WE USE TO SPEAK

Before publication, perform a proper trademark, bookstore/catalog, and KDP title-market check.

## 3. Publishing metadata

KDP's current metadata guidance says the title field should contain the actual book title as shown on the cover, and title/subtitle/cover information should match. KDP recommends relevant keyword phrases and relevant categories and warns against misleading metadata.

Potential keyword concepts after the manuscript is complete:
- communication beyond words
- creative expression
- human communication
- finding your voice
- creativity and purpose
- communication and meaning
- personal expression

These are research starting points, not final metadata.

## 4. Category direction

Potential category families:
- Communication
- Creativity
- Personal Growth
- Philosophy
- Writing/Expression

Final categories must reflect the completed manuscript.

## 5. Real-world examples

When discussing a real artist, cartoonist, musician, programmer, entrepreneur, teacher, or other public figure:
- verify their identity and work
- verify dates and facts
- quote only verified material
- never invent biography
- do not imply endorsement
- distinguish observation from interpretation

## 6. Conceptual precision

Avoid the simplistic statement:

> “Everything is language.”

A more precise formulation is:

> **Many things can function as forms of communication because people use them to carry meaning.**

A hoe is not literally a language in the same technical sense as English. But a farmer's work can communicate values, intention, identity, knowledge, and contribution.

Code is not simply “English for computers.” It is a formal system used to instruct machines, while the software built with it can create experiences and consequences for humans.

## 7. Ethical refinement

The original concept included thieves, killers, rapists, robbers, and terrorists.

Retain the insight that actions can communicate meaning, but never romanticize or legitimize criminal harm.

Better formulation:

> **Human actions can communicate meaning, but meaning does not determine moral worth.**

A destructive act can send a message while violating rights and causing serious harm.

## 8. Strongest original contribution

The book should go beyond:

> “Communication is more than words.”

That territory is crowded.

Its stronger contribution is:

> **Every person has some medium through which they can place meaning into the world. The responsibility is to discover that medium, develop it, and choose what message to send through it.**

That is the idea the manuscript should own.
