# COURSE 2 — THE POWER OF ELECTRON
### From Web Technologies to Desktop Applications, Automation, and Native Capabilities

**Promise:** understand why Electron exists and how web skills become desktop applications.

Electron combines web technologies, Node.js, Chromium, and native capabilities for cross-platform desktop apps. citeturn0search11

### Modules
1. Why desktop apps?
2. Why Electron?
3. Architecture
4. Main, renderer, preload
5. Context isolation and security
6. IPC
7. Native menus/windows/files/notifications
8. Packaging and distribution
9. Automation
10. Background work
11. Performance and memory
12. When NOT to use Electron
13. Capstone

Electron uses a multi-process architecture and IPC connects processes for many desktop operations. citeturn0search14turn0search2

**Capstone:** secure desktop automation/productivity app with preload, IPC, native file access, logging and packaging.


## Course design standard

Teach every subject through: **WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**.

Do not make the course a button-clicking tutorial. Build mental models first, then practical skill, then architecture and judgment.

Use current official documentation for fast-changing technologies. Version-anchor labs and specifications. Never invent facts, citations, benchmarks, quotations, or capabilities.

Every destructive operation must be clearly marked, previewable where possible, and taught with recovery/safety considerations.
