# COURSE 5 — THE HIDDEN POWER OF NPM & DAEMONS
### Packages, Scripts, Processes, and the Machinery Behind Modern JavaScript Systems

**Promise:** understand npm as project automation infrastructure, then understand long-running processes/services.

npm supports package.json scripts and lifecycle events, including pre/post behavior. citeturn0search1turn0search7

### Modules
1. npm mental model
2. package.json
3. dependencies/devDependencies
4. versions and lockfiles
5. install/ci/update/publish
6. scripts and lifecycle
7. project automation
8. dependency security
9. process vs service vs daemon
10. long-running processes
11. monitoring/restarting
12. logs and health checks
13. graceful shutdown
14. when daemon/service architecture fits
15. Capstone

**Capstone:** Node project with development/test/build/operations scripts, plus a managed long-running service with logs, health checks and graceful shutdown.


## Course design standard

Teach every subject through: **WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**.

Do not make the course a button-clicking tutorial. Build mental models first, then practical skill, then architecture and judgment.

Use current official documentation for fast-changing technologies. Version-anchor labs and specifications. Never invent facts, citations, benchmarks, quotations, or capabilities.

Every destructive operation must be clearly marked, previewable where possible, and taught with recovery/safety considerations.
