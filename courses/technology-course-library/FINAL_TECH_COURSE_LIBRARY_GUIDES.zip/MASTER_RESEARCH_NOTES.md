# MASTER RESEARCH NOTES — TECH COURSE LIBRARY

## Verified foundations

### Windows
Microsoft identifies Command shell and PowerShell as Windows command-line shells used for direct OS interaction and automation. It describes PowerShell as extending Command shell capabilities and recommends PowerShell for robust Windows automation. citeturn1search0

PowerShell also has explicit command-resolution rules and can run native executables. citeturn1search2turn1search16

### Electron
Electron combines web technologies, Node.js, Chromium and native capabilities for cross-platform desktop applications. citeturn0search11 Its multi-process architecture and IPC are central to desktop application design. citeturn0search14turn0search2

### npm
npm package.json supports scripts, dependencies and lifecycle behavior; scripts can automate development and operational tasks. citeturn0search1turn0search7

### Pipelines
Microsoft describes CI as automated integration/testing and CD as build/test/deployment processes. citeturn0search9

### React Native and Flutter
React Native builds on React/JavaScript. Flutter uses Dart and a different rendering model, making requirement-based comparison more useful than a universal ranking. citeturn0search0turn0search5

### MCP
MCP uses hosts, clients and servers and exposes tools, resources and prompts. citeturn1search3turn1search4 The July 28, 2026 specification changed important protocol behavior, so the course must explicitly identify its target revision. citeturn1search10

### Data lakes
AWS describes a data lake as centralized storage for structured and unstructured data at scale, supporting analytics and machine learning. citeturn0search6

## Research rule

Before selling a course, refresh:
- current versions
- official installation steps
- security guidance
- API/specification changes
- pricing/licensing
- benchmark evidence
- platform-specific behavior

Never silently teach stale information.

## Library principle

Do not teach technology worship. A powerful course shows what a tool can do, what it cannot do, what it costs, what risks it introduces, what alternatives exist, and which requirements make it appropriate.
