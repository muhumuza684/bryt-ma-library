# TECH COURSE LIBRARY — MASTER INDEX

These are the first 11 courses in the library.

| # | Title | Focus |
|---|---|---|
| 1 | **The Hidden Power of the Command Line** | CMD, PowerShell, permissions, elevation, automation |
| 2 | **The Power of Electron** | Desktop apps, IPC, process model, automation |
| 3 | **Pipelines** | CI/CD, testing, artifacts, deployment |
| 4 | **The Power of Chatbots & APIs** | Conversational systems and integrations |
| 5 | **The Hidden Power of npm & Daemons** | Packages, scripts, lifecycle, services |
| 6 | **The Great Mobile Choice** | React Native vs Flutter |
| 7 | **Building IDEs** | IDE architecture and developer tooling |
| 8 | **The Power of Research** | Evidence, verification, experiments |
| 9 | **MCP** | AI interoperability and external capabilities |
| 10 | **The Data Lake** | Data architecture and analytics |
| 11 | **Compare** | Technical comparison and decision-making |

## Library philosophy

These are not ordinary tutorials. Every course teaches:

**WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**

Fast-moving technologies must be version-anchored before publication.
