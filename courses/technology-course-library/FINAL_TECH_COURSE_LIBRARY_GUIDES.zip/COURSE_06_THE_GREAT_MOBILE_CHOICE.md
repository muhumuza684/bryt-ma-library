# COURSE 6 — THE GREAT MOBILE CHOICE
### React Native and Flutter — Why, Where, When, How, and When Not to Use Each

**Promise:** teach framework comparison as engineering judgment, not tribalism.

React Native builds on React and JavaScript. Flutter uses Dart and a different rendering approach; Flutter's documentation explicitly contrasts its approach with React Native. citeturn0search0turn0search4turn0search5

### Modules
1. Mobile-development problem
2. Native vs cross-platform
3. React Native model
4. Flutter model
5. Languages/ecosystems
6. UI/rendering
7. Native integration
8. Performance
9. Developer experience
10. Libraries/ecosystem
11. Team fit
12. Testing/deployment
13. When RN fits
14. When Flutter fits
15. When neither fits
16. Comparison methodology
17. Same-app exercise
18. Capstone

Compare requirements, platform targets, skills, native integration, performance, delivery speed, maintenance, cost and risk. Do not declare a universal winner.

**Capstone:** implement/analyze the same product in both and create a requirements-based decision record.


## Course design standard

Teach every subject through: **WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**.

Do not make the course a button-clicking tutorial. Build mental models first, then practical skill, then architecture and judgment.

Use current official documentation for fast-changing technologies. Version-anchor labs and specifications. Never invent facts, citations, benchmarks, quotations, or capabilities.

Every destructive operation must be clearly marked, previewable where possible, and taught with recovery/safety considerations.
