# COURSE 1 — THE HIDDEN POWER OF THE COMMAND LINE
### CMD, PowerShell, Permissions, and the Windows Control Surface

**Promise:** turn the “black window” into an understandable control surface for Windows.

### Modules
1. GUI vs command line
2. CMD fundamentals
3. PowerShell fundamentals
4. CMD vs PowerShell
5. Normal execution vs elevation
6. Run as administrator and UAC
7. PATH and command discovery
8. Files, processes, services, networking
9. Automation and scripting
10. Error handling and diagnostics
11. Safe administrative scripting
12. Capstone: Windows diagnostic/automation toolkit

Microsoft documents CMD and PowerShell as Windows command-line shells for direct OS interaction and automation; it describes PowerShell as extending the Command shell and recommends PowerShell for robust Windows automation. citeturn1search0

Teach elevation as a security context, not a magic “power button.” Windows Terminal documents administrator-mode sessions as elevated shells. citeturn0search12

**Labs:** equivalent CMD/PowerShell tasks, environment inspection, process/service inspection, a safe system-audit script, and a task that appropriately requires elevation.


## Course design standard

Teach every subject through: **WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**.

Do not make the course a button-clicking tutorial. Build mental models first, then practical skill, then architecture and judgment.

Use current official documentation for fast-changing technologies. Version-anchor labs and specifications. Never invent facts, citations, benchmarks, quotations, or capabilities.

Every destructive operation must be clearly marked, previewable where possible, and taught with recovery/safety considerations.
