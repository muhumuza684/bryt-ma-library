# COURSE 8 — THE POWER OF RESEARCH
### How to Ask Better Questions, Find Evidence, Test Ideas, and Build With Confidence

**Promise:** make research an engineering superpower.

### Modules
1. What research is
2. Why research saves time
3. Questions before searches
4. Primary vs secondary sources
5. Documentation/papers/standards/datasets
6. Search strategy
7. Source quality
8. Cross-checking
9. Fact vs inference vs opinion vs marketing
10. Experiments/prototypes
11. Reproducibility
12. Research with AI
13. Technical literature reviews
14. Decision research
15. Research-to-action
16. Capstone

**Research loop:** Question → Search → Source → Verify → Compare → Test → Document → Decide → Revisit.

**Capstone:** research a real technical decision, verify evidence, run a validation experiment and produce a defensible decision record.


## Course design standard

Teach every subject through: **WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**.

Do not make the course a button-clicking tutorial. Build mental models first, then practical skill, then architecture and judgment.

Use current official documentation for fast-changing technologies. Version-anchor labs and specifications. Never invent facts, citations, benchmarks, quotations, or capabilities.

Every destructive operation must be clearly marked, previewable where possible, and taught with recovery/safety considerations.
