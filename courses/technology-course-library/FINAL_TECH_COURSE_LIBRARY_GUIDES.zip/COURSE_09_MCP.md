# COURSE 9 — MCP
### Why the Model Context Protocol Exists, What It Solves, and How to Build With It

**Promise:** understand MCP as an interoperability protocol for AI applications.

MCP defines hosts, clients and servers and primitives including tools, resources and prompts. citeturn1search3turn1search4 The July 28, 2026 specification introduced major changes including a stateless protocol core, so the course must state the specification revision used by its labs. citeturn1search10

### Modules
1. The problem before MCP
2. AI applications and external capabilities
3. Why ad-hoc integrations become difficult
4. MCP concepts
5. Host/client/server
6. Tools/resources/prompts
7. Capability negotiation
8. Transport/protocol concepts
9. Security and consent
10. Minimal MCP server
11. Client connection
12. Tool schemas
13. Context boundaries
14. Testing/observability
15. Versioning
16. When MCP fits
17. When a normal API is simpler
18. Capstone

**Capstone:** safe MCP server exposing tools/resources, connected to a client, with documented permissions and boundaries.


## Course design standard

Teach every subject through: **WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**.

Do not make the course a button-clicking tutorial. Build mental models first, then practical skill, then architecture and judgment.

Use current official documentation for fast-changing technologies. Version-anchor labs and specifications. Never invent facts, citations, benchmarks, quotations, or capabilities.

Every destructive operation must be clearly marked, previewable where possible, and taught with recovery/safety considerations.
