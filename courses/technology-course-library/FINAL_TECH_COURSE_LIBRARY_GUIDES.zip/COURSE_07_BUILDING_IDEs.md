# COURSE 7 — BUILDING IDEs
### Why Developer Environments Matter, How They Work, and When to Build Your Own

**Promise:** understand an IDE as an ecosystem, not merely an editor with buttons.

### Modules
1. Editor vs IDE vs workspace
2. Why build an IDE?
3. When not to
4. Architecture
5. Text editor
6. Project explorer
7. Syntax highlighting
8. Parsing/language services
9. Autocomplete/diagnostics
10. Search/navigation
11. Terminal
12. Debugging
13. Extensions
14. Settings/workspace state
15. Performance
16. Security/untrusted code
17. Capstone

**Capstone:** build a small IDE/workbench for one language/workflow with editor, explorer, search, terminal, diagnostics and one specialized tool.


## Course design standard

Teach every subject through: **WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**.

Do not make the course a button-clicking tutorial. Build mental models first, then practical skill, then architecture and judgment.

Use current official documentation for fast-changing technologies. Version-anchor labs and specifications. Never invent facts, citations, benchmarks, quotations, or capabilities.

Every destructive operation must be clearly marked, previewable where possible, and taught with recovery/safety considerations.
