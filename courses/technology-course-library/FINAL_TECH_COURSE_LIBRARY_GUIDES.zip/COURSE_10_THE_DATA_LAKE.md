# COURSE 10 — THE DATA LAKE
### Why Data Needs a Place to Flow, When to Use One, and How to Build It Well

**Promise:** understand a data lake as architecture, not merely a huge folder.

AWS defines a data lake as a centralized repository for structured and unstructured data at scale, supporting analytics, processing, visualization and machine learning. citeturn0search6

### Modules
1. Problem a data lake solves
2. Lake vs database vs warehouse vs lakehouse
3. Data types
4. Ingestion
5. Storage and formats
6. Metadata/catalogs
7. Partitioning
8. Data quality
9. Governance/access
10. Security/privacy
11. Batch vs streaming
12. Analytics/ML
13. Lifecycle/retention
14. Cost
15. Data swamp failure mode
16. When NOT to use a lake
17. Capstone

**Architecture:** Sources → ingestion → raw → validated/curated → catalog/governance → analytics/ML → consumers.

**Capstone:** small data-lake-style system with ingestion, raw/curated zones, metadata, validation and analytics.


## Course design standard

Teach every subject through: **WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**.

Do not make the course a button-clicking tutorial. Build mental models first, then practical skill, then architecture and judgment.

Use current official documentation for fast-changing technologies. Version-anchor labs and specifications. Never invent facts, citations, benchmarks, quotations, or capabilities.

Every destructive operation must be clearly marked, previewable where possible, and taught with recovery/safety considerations.
