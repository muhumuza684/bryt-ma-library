# COURSE 11 — COMPARE
### The Power of Making Better Technical Choices

**Promise:** turn comparison from opinion into a repeatable engineering discipline.

### Modules
1. Why comparison is a technical skill
2. Comparison vs opinion
3. Define the decision
4. Requirements before technologies
5. Criteria and weights
6. Apples-to-apples comparisons
7. Benchmarks and experiments
8. Documentation/evidence
9. Total cost of ownership
10. Performance vs complexity
11. Short vs long term
12. Team/ecosystem fit
13. Risk/reversibility
14. Build vs buy vs reuse
15. Decision matrices and limits
16. Confirmation bias
17. Technical decision records
18. Capstone

**Signature framework:**
Problem → Constraints → Options → Criteria → Evidence → Experiment → Trade-offs → Decision → Review

Key principle:
> **Best for what, under which constraints, for whom, and for how long?**

**Capstone:** compare two technologies for a real project and produce a documented evidence-based decision record.


## Course design standard

Teach every subject through: **WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**.

Do not make the course a button-clicking tutorial. Build mental models first, then practical skill, then architecture and judgment.

Use current official documentation for fast-changing technologies. Version-anchor labs and specifications. Never invent facts, citations, benchmarks, quotations, or capabilities.

Every destructive operation must be clearly marked, previewable where possible, and taught with recovery/safety considerations.
