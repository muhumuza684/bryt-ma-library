# COURSE 3 — PIPELINES
### How to Design, Build, Automate, and Scale Reliable Software Delivery

**Promise:** understand software delivery as a flow from change to verified artifact to deployment.

Microsoft describes CI around automated integration/testing and CD around building, testing and deploying software. citeturn0search9

### Modules
1. What is a pipeline?
2. Why pipelines exist
3. Pipeline vs script vs workflow
4. Inputs, stages, jobs, steps
5. CI
6. CD
7. Tests
8. Secrets and permissions
9. Branches and triggers
10. Artifacts and caching
11. Failures, logs and retries
12. Parallelism
13. Platform implementations
14. When pipelines are overkill
15. Capstone

**Signature questions:** What triggers it? What enters? What must be proven? What artifact exits? Where is it deployed? What happens when it fails?

**Capstone:** test, build, package and deploy a small application with visible logs and failure handling.


## Course design standard

Teach every subject through: **WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**.

Do not make the course a button-clicking tutorial. Build mental models first, then practical skill, then architecture and judgment.

Use current official documentation for fast-changing technologies. Version-anchor labs and specifications. Never invent facts, citations, benchmarks, quotations, or capabilities.

Every destructive operation must be clearly marked, previewable where possible, and taught with recovery/safety considerations.
