# COURSE 4 — THE POWER OF CHATBOTS & APIs
### How Conversational Systems Connect People, Software, and Services

**Promise:** move beyond “make a chatbot” into architecture.

### Modules
1. What a chatbot is
2. Rules vs AI
3. Conversation state
4. APIs
5. HTTP, JSON and authentication
6. External services
7. Tools/functions
8. Databases and memory
9. Webhooks
10. WhatsApp/web/mobile architectures
11. Security and rate limits
12. Uncertainty and human handoff
13. Testing
14. Capstone

**Architecture:** User → channel → application → model/logic → tools/APIs → data/services → response.

**Capstone:** chatbot that answers questions, calls an external API, stores appropriate state, validates inputs, handles failures and supports human handoff.


## Course design standard

Teach every subject through: **WHY → WHAT → HOW → WHEN → WHEN NOT → ALTERNATIVES → TRADE-OFFS → SECURITY → LABS → CAPSTONE**.

Do not make the course a button-clicking tutorial. Build mental models first, then practical skill, then architecture and judgment.

Use current official documentation for fast-changing technologies. Version-anchor labs and specifications. Never invent facts, citations, benchmarks, quotations, or capabilities.

Every destructive operation must be clearly marked, previewable where possible, and taught with recovery/safety considerations.
